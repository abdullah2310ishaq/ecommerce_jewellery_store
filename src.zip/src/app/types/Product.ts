export type Product = {
    id: string; // Change to string if necessary
    name: string;
    price: string;
    img: string;
  };//0hello
