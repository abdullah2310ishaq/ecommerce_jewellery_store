"use client";

import HeroSlider from "@/app/components/HeroSlider";

const Hero = () => {
  return (
    <section className="relative w-full">
      <HeroSlider />
    </section>
  );
};

export default Hero;
